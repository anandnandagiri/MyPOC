


dotnet watch run
Install-Package Google.Apis.Calendar.v3


https://aad.portal.azure.com/
http://aka.ms/aadv2

https://github.com/microsoftgraph/msgraph-training-aspnetmvcapp

Client ID
110197253841-2388jjcue84lqd3dagq9peck7qn5kgt0.apps.googleusercontent.com
Client Key
1qgYkm-s98V7rURHLwb39D2z